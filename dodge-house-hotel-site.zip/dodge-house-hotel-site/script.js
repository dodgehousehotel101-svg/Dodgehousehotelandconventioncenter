// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('primary-nav');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
}

// Footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Demo booking handler (replace with your booking engine deep link)
const bookingForm = document.querySelector('.booking-form');
if (bookingForm) {
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(bookingForm);
    const q = new URLSearchParams({
      checkin: data.get('checkin') || '',
      checkout: data.get('checkout') || '',
      guests: (data.get('guests') || '').toString(),
      promo: (data.get('promo') || '').toString()
    }).toString();
    // Example redirect placeholder:
    // location.href = `/rooms.html?${q}`;
    alert(`Searching rooms…\n\n${q}`);
  });
}
